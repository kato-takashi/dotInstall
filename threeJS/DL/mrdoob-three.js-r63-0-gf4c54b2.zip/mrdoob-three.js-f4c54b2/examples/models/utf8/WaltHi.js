{
  "materials": {
    "lambert4sg": { "Kd": [204, 204, 204] }
  },
  "decodeParams": {
    "decodeOffsets": [-5863,24,-6527,0,0,-511,-511,-511],
    "decodeScales": [0.004800,0.004800,0.004800,0.000978,0.000978,0.001957,0.001957,0.001957]
  },
  "urls": {
    "WaltHi.utf8": [
      { "material": "lambert4sg",
        "attribRange": [0, 55294],
        "codeRange": [442352, 216890, 108427]
      },
      { "material": "lambert4sg",
        "attribRange": [659242, 31285],
        "codeRange": [909522, 121073, 60507]
      }
    ]
  }
}